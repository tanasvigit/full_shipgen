# Screen: maintenance/maintenances/index

| Property | Value |
|----------|-------|
| **Engine** | FleetOps |
| **Route name** | `fleet_ops.maintenance.maintenances` |
| **URL** | `/fleet-ops/maintenance/maintenances` |
| **Template** | `packages/fleetops/addon/templates/maintenance/maintenances/index.hbs` |
| **Controller** | `packages\fleetops\addon\controllers\maintenance\maintenances\index.js` |
| **Route** | `packages\fleetops\addon\routes\maintenance\maintenances\index.js` |

---

## 1. Layout structure

- Resource tabular (list + filters + table)

```
[Header: title + actions]
[Filters row]
[Data table with pagination]
[Optional: map/kanban toggle above]
```

---

## 2. Fields (form inputs)

| Label | Value binding | Type | Notes |
|-------|---------------|------|-------|
| _No InputGroup fields in route template — see composed components below_ | | | |

---

## 3. Tables

| Column (i18n) | valuePath | Sort | Filter |
|---------------|-----------|------|--------|
| column.summary | `summary` | yes | yes |
| column.asset | `maintainable.name` | yes | yes |
| column.performed-by | `performed_by.name` | yes | yes |
| column.type | `type` | yes | yes |
| column.status | `status` | yes | yes |
| column.priority | `priority` | yes | yes |
| column.scheduled-at | `scheduledAt` | yes | yes |
| column.total-cost | `total_cost` | yes | yes |
| column.created-at | `createdAt` | yes | yes |
| column.updated-at | `updatedAt` | yes | yes |


---

## 4. Tabs

_No tab getter — single panel or tabs in parent_

---

## 5. Buttons & actions

| Label | Action / handler | Conditions |
|-------|------------------|------------|



---

## 6. Modals, drawers, overlays

_None in template — may be triggered from controller actions_

---

## 7. Filters & query params

**Query params:** _none in controller_



---

## 8. Validations & conditional logic

- _See controller and component JS for business rules_

---

## 9. API & data

| Interaction | Detail |
|-------------|--------|
| Data load | `store.query('maintenance')` |


---

## 10. Permissions

- `fleet-ops view maintenance`
- `fleet-ops update maintenance`
- `fleet-ops delete maintenance`

---

## 11. Registries / extensions / hooks

_No registry slots in this template_

---

## 12. Navigation flow

- **Enter:** Navigate to `/fleet-ops/maintenance/maintenances`
- **Exit:** Standard back or transition per host router


---

## 13. Responsive / mobile

- Console shell uses `Layout::MobileNavbar` for primary nav on small screens
- Sidebar hidden on map-heavy FleetOps detail routes (see parent controller `sidebar.hideNow()`)
- Tables use horizontal scroll / pagination footer

---

## 14. Reusable component mapping

| Ember | Custom design system |
|-------|---------------------|
| `Layout::Resource::Tabular` | TBD |

---

## 15. Composed components (full UI)


---

## 16. Source files to mirror

- Template: `packages/fleetops/addon/templates/maintenance/maintenances/index.hbs`
- Controller: `packages\fleetops\addon\controllers\maintenance\maintenances\index.js`
- Route: `packages\fleetops\addon\routes\maintenance\maintenances\index.js`


---

## Deep specification (auto-enriched)

### Controller actions/tabs (`packages/fleetops/addon/controllers/maintenance/maintenances/index.js`)

**Tabs:**
- Delete selected...



---


---


---


---


---


---


---


---

## 17. Runtime behavior (source-traced)

> Traced from controllers, routes, services, and templates. Reproduce this section for parity without opening Ember source.

### Route lifecycle


### Controller state & services

**Injected services:** `maintenanceActions`, `intl`

**Query params:** `type`, `status`, `priority`, `page`, `limit`, `sort`, `query`, `public_id`, `created_at`, `updated_at`

### Action menu / header buttons

| Action | Handler | Disabled when |
|--------|---------|---------------|
| common.refresh | `maintenanceActions.refresh` | `—` |
| common.new | `maintenanceActions.transition` | `—` |
| common.import | `maintenanceActions.import` | `—` |
| common.export | `maintenanceActions.export` | `—` |


### Service action flows

#### `maintenance-actions.refresh()`


**Navigation:**
- `router.refresh()` after success

#### `maintenance-actions.import()`


#### `maintenance-actions.export()`


### Notifications pattern (global)

- Success: `notifications.success(intl.t(...))`
- Warning: `notifications.warning(...)` — validation/precondition failed
- Error: `notifications.serverError(error)` — parses API error payload

### Realtime / sockets

- Realtime only where `orderSocketEvents` or SocketCluster is injected on this screen (see service flows above)
- Company channel `company.{companyId}` may patch models (e.g. `order.driver_assigned`) — see `order-socket-events` service doc

### Permission branching

- Use `abilities.can('fleet-ops <verb> <resource>')` / `cannot` in routes and column definitions
- Table row actions inherit `permission` on column definitions

### Registry / extensions

- Dynamic tabs/components from `menuService.getMenuItems(registryName)`
- `RegistryYield` renders extension components with `@permission` prop

### Mobile / responsive

- Console `hiddenSidebarRoutes` forces header-only nav on home, notifications, virtual pages
- Order detail hides sidebar entirely; map layout uses full width
- Tables: fixed footer pagination; horizontal scroll on narrow viewports

### List resource behavior

- Uses `Layout::Resource::Tabular` — search debounced via controller task
- Pagination: `page` query param updates model
- Bulk actions from `bulkActions` getter on controller
- Row click → transition to details route
- Export/import via `*Actions.export/import`

